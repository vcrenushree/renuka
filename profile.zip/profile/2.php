<html>
	<body>
		<?php
$Name=$_POST['name'];
$Place=$_POST['place'];
$Add=$_POST['add'];
$Phone=$_POST['phone'];
$Email=$_POST['email'];


echo "your profile";?>
		<br>
		<?php

echo "NAME:$Name"; ?>
		<br>
		<?php

echo "PLACE:$Place";?>
		<br>
		<?php

echo "ADD:$Add";?>
		<br>
		<?php

echo "PHONE:$Phone";?>
		<br>
		<?php

echo "EMAIL:$Email";
?>

